<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔓 | Vyola App</title>
    <link rel="stylesheet" href="styles/styleHeight950.css">
    <script src="index.js"></script>
</head>

<body>

    <div class = "header">

    <div class = "headerLeft">
        <a href = "home.php">
            <img src = "img/logo.png" id = "logoHeader">
        </a>
    </div>

    <div class = "headerRight">
        <ul>
            <li> <a href = "home.php" class = "linkHeader"> Home </a> </li>
            <li> <a href = "#" class = "linkHeader"> Store </a> </li>
            <li> <a href = "about.php" class = "linkHeader"> About </a> </li>
        </ul>
    </div>

    <a href = "login.php">
        <img src = "img/login2.png" id = "logoHeader2">
    </a>

    </div>

    <h1 class = "title">
    Vyola User Dashboard
    </h1>

    <p class = "subtitle">
    Alternative app stores at their finest!
    </p>

</body>

</html>
